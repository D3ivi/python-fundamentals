meters = int(input())

print(f'{meters / 1000:.2f}')
