pounds = int(input())

dollars = pounds * 1.31

print(f'{dollars:.3f}')