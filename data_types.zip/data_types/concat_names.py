first_name = input()
second_name = input()
delimiter = input()

print(f'{first_name}{delimiter}{second_name}')
